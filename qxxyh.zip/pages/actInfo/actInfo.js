// pages/actAssess/actAssess.js
let API = require('../../utils/api.js');

Page({
  data: {
    actInfo: []
  },
  onLoad: function (options) {
    console.log(JSON)
    console.log("JSON"+JSON.parse(options.actInfo))
    let actInfo = JSON.parse(options.actInfo)
    this.setData({
      actInfo: actInfo
    })
  },
  signUp: function () {
    var that = this
    wx.showModal({
      title: '提示',
      content: '确认报名此次活动？',
      success(res) {
        if (res.confirm) {
          wx.request({
            url: API.BASE_URL + '/api/eventApply',
            method: 'POST',
            header: {
              'content-type': 'application/json',
            },
            data: {
              student_id: getApp().globalData.stuID,
              event_id: that.data.actInfo.eventId
            },
            success: (res) => {
              console.log(res.data)
              if (res.data === "SignUpSuccess") {
                wx.showToast({
                  title: "报名成功",
                  icon: 'success',
                  duration: 1500
                })
              } else if (res.data === "SignUpFail_AlreadyIn") {
                wx.showToast({
                  title: "报名失败，请勿重复报名",
                  icon: 'none',
                  duration: 1500
                })
              } else if (res.data === "SignUpFail_Full") {
                wx.showToast({
                  title: "报名失败，活动人数已满",
                  icon: 'none',
                  duration: 1500
                })
              } else if (res.data === "SignUpFail_LowCredit") {
                wx.showToast({
                  title: "报名失败，信用分不足",
                  icon: 'none',
                  duration: 1500
                })
              }
            }
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  callUs() {
    var that = this
    wx.request({
      url: API.BASE_URL + '/api/qryEventUserPhone',
      method: 'POST',
      header: {
        'content-type': 'application/json',
      },
      data: {
        event_id: that.data.actInfo.eventId
      },
      success: (res) => {
        wx.makePhoneCall({
          phoneNumber: res.data.toString()
        })
      }
    })
  }
})