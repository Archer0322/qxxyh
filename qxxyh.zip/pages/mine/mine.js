// pages/mine/mine.js
//sort.js
//獲取應用實例
let API = require('../../utils/api.js');
var app = getApp
let http = require('../../utils/http.js');

Page({
  data: {
    qrCodeSrc: '',
    myCodeDisplay: 'none',
    loading: true,
    loginStatus: getApp().globalData.loginOrNot,
    avatarUrl: "",
    userName: "",
    userScore: Number,
    serviceTime: Number
  },
  add_address_fun: function () {
    wx.navigateTo({
      url: 'add_address/add_address',
    })
  },
  requestFunction: function () {
    wx.request({
      url: API.BASE_URL + '/api/user/qryUser',
      method: 'POST',
      header: {
        'content-type': 'application/json',
      },
      data: {
        stuID: getApp().globalData.stuID
      },
      success: (res) => {
        console.log("heredata4 in mine:", res.data)
        this.setData({
          avatarUrl: res.data.userAvator,
          userName: res.data.userName,
          userScore: res.data.userScore,
          loading: false
        })
      }
    })
  },
  onShow: function (options) {
    if (getApp().globalData.loginOrNot) {
      this.requestFunction()
      this.setData({
        loading: false,
        loginStatus: getApp().globalData.loginOrNot
      }) //setData刷新渲染页面的数据
      console.log(getApp().globalData.loginOrNot+this.data.userName + this.data.userScore)
      wx.navigateTo({
        url: './mine.wxml'
      }) //navigateTo使得页面刷新
    }
  },
  onLoad: function (options) {
    var that = this;
    if (getApp().globalData.loginOrNot) {
      this.requestFunction()
    }
    //this.getMyCode()
  },
  baseInfo: function () {
    wx.navigateTo({
      url: '/pages/mine_baseInfo/mine_baseInfo',
    })
  },
  safeCenter: function () {
    wx.navigateTo({
      url: '/pages/mine_safeCenter/mine_safeCenter',
    })
  },
  myAct: function () {
    wx.navigateTo({
      url: '/pages/mine_myAct/mine_myAct',
    })
  },
  aboutUs: function () {
    wx.navigateTo({
      url: '/pages/mine_aboutUs/mine_aboutUs',
    })
  },
  scanButton: function () {
    if (this.data.isClickScan == false) {
      this.setData({
        display: 'block'
      })
      this.setData({
        isClickScan: true
      })
    } else {
      this.setData({
        display: 'none'
      })
      this.setData({
        isClickScan: false
      })
    }
  },
  getMyCode: function () {
    wx.request({
      url: API.BASE_URL + '/api/qrcode/getUserCode',
      method: 'POST',
      header: {
        'content-type': 'application/json',
      },
      success: (res) => {
        this.setData({
          qrCodeSrc: res.data
        })
      },
      fail: (res) => {
        console.log(res)
      }
    })
  },
  myCode: function () {
    if (this.data.myCodeDisplay == 'none') {
      this.setData({
        myCodeDisplay: 'block'
      })
    } else {
      this.setData({
        myCodeDisplay: 'none'
      })
    }
  },
  login: function () {
    wx.navigateTo({
      url: '/pages/login/login',
    })
  },
  logout: function () {
    wx.redirectTo({
      url: '/pages/login/login',
    })
    let globalData = getApp().globalData
    globalData.loginOrNot = false
    globalData.stuID = ""
  },
})