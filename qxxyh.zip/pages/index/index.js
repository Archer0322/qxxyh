// pages/index/index.js
let API = require('../../utils/api.js');
var loginOrNot
Page({
  data: {
    current: 1,
    totalPage: 0,
    size: 5,
    activityList:[]
  },
  exit() {
    wx.redirectTo({
      url: '/pages/login/login',
    })
    let globalData = getApp().globalData
    globalData.loginOrNot = false
    globalData.stuID = ""
  },
  actAssess:function(e){
    console.log("id: "+e.currentTarget.dataset.id)
    var eventId = e.currentTarget.dataset.id
    let actList = this.data.activityList
    let eventInfo
    for (let item of actList) {
      if(item.eventId == eventId) {
        eventInfo = item
      }
    }
    wx.navigateTo({
      url: '/pages/actInfo/actInfo?actInfo=' + JSON.stringify(eventInfo)
    })
  },
  
  getActList() {
    var that = this
    wx.request({
      url: API.BASE_URL + '/api/qryEventForPage/index',
      method: 'POST',
      header: {
        'content-type': 'application/json',
      },
      data: {
        current: that.data.current,
        size: that.data.size,
        status: "全部"
      },
      success: (res) => {
        console.log("here act:",res.data)
        that.setData({
          activityList:res.data.records,
          totalPage: res.data.pages
        })
      }
    })  
  },
  changePage({ detail }) {
    var that = this
    const type = detail.type;
    if (type === 'next') {
      that.setData({
        current: that.data.current + 1
      });
    } else if (type === 'prev') {
      that.setData({
        current: that.data.current - 1
      });
    }
    that.getActList()
  },
  onShow() {
    this.setData({
      loginOrNot : getApp().globalData.loginOrNot
    })
  },
  onLoad() {
    this.getActList()
  }
  

})