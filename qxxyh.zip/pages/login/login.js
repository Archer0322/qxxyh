let API = require('../../utils/api.js');
var onloadedOrNot = false

Page({
  data:{
    userId:'',
    userPwd:'',
    role:''
  },
  getUserId:function(e){
    this.data.userId = e.detail.value;
  },
  getUserPwd:function(e){
    this.data.userPwd=e.detail.value;
  },
  getUserRole:function(e){
    this.data.role = e.detail.value;
  },
  login:function(e){
    var username = this.data.userId;
    var password = this.data.userPwd;
    var role = this.data.role;
    // if(role == 1) {
    //   wx.showToast({
    //     title: '管理员请通过后台登录',
    //     icon: 'none',
    //     duration: 2000
    //   })
    //   return
    // }
    var requestData = {
      _id: 0,
      username: "114514000",
      password: "123456",
      type: parseInt(role)
  };
    wx.request({
      url: API.BASE_URL + '/api/user/login',
      method: 'POST',
      header: {
        'content-type': 'application/json'
        // 'cookie' : wx.getStorageSync('cookie') 请求带cookie
      },
      data: requestData,
      success: function (res) {
        var data=res.data;
        if(data === "LoginSuccess"){
          // wx.setStorageSync('cookie', data.data)
          // wx.setStorageSync('role', role)
          getApp().globalData.stuID = username
          getApp().globalData.loginOrNot = true
          wx.showToast({
            title: "登录成功",
            icon: 'success',
            duration: 2000
          })
          wx.switchTab({
            url: '/pages/index/index',
          })
        }else{
          wx.showToast({
            title: data,
            icon:'none',
            duration: 2000
          })
        }        
      },
      fail: function(e) {
        wx.showToast({
          title: e,
          icon: 'none',
          duration: 2000
        })
      }
    })
  },
  register:function(){
    wx.navigateTo({
      url: '/pages/register/register',
    })
  }
})