// pages/mine_myAct_comment/mine_myAct_comment.js
let API = require('../../utils/api.js');

var d = new Date()
var year = d.getFullYear(); // 获取年份
var month = d.getMonth() + 1; // 获取月份（注意：月份是从 0 开始的，需要加 1）
var day = d.getDate(); // 获取日期
var hour = d.getHours(); // 获取小时
var minute = d.getMinutes(); // 获取分钟

// 将月份、日期、小时、分钟转换为两位数的字符串格式
month = month < 10 ? '0' + month : month;
day = day < 10 ? '0' + day : day;
hour = hour < 10 ? '0' + hour : hour;
minute = minute < 10 ? '0' + minute : minute;


const { $Message } = require('../../dist/base/index');
Page({
  data: {
    actInfo: {},
    grade: [{
      id: 1,
      name: '非常满意',
    }, {
      id: 2, 
      name: '比较满意'
    }, {
      id: 3,
      name: '比较不满意'
    }, {
      id: 4,
      name: '非常不满意',
    }],
    currentGrade: '',
    position: 'left',
    evaluateTxt: ''
  },
  onLoad(options) {
    
    this.setData({
      actInfo: JSON.parse(options.actInfo)
    })
    console.log("actInfo",this.data.actInfo)
  },
  handleGradeChange({ detail = {} }) {
    this.setData({
      currentGrade: detail.value
    })
    console.log("detail.value", detail.value)
  },
  goback() {
    wx.navigateBack({
      delta: 1
    })
  },
  bindTextAreainput(e) {
    this.setData({
      evaluateTxt: e.detail.value,
    })
    console.log(e.detail.value)
  },
  publish() {
    if (this.data.currentGrade == '' || this.data.evaluateTxt == '') {
      console.log("this.data.currentGrade:", this.data.currentGrade)
      console.log("this.data.evaluateTxt:", this.data.evaluateTxt)
      wx.showToast({
        title: '满意度或内容不能为空!',
        icon: 'none',
        duration: 1500
      })
      return
    }
    var that = this
    wx.request({
      url: API.BASE_URL + '/api/comment',
      method: 'POST',
      header: {
        'content-type': 'application/json',
        'cookie': wx.getStorageSync('cookie') //请求带cookie
      },
      data: {
        student_id: getApp().globalData.stuID,
        event_id: this.data.actInfo.eventId,  //活动的唯一id
        comment_content: this.data.evaluateTxt,
        rate: this.data.currentGrade,
        post_time: year + '-' + month + '-' + day + ' ' + hour + ':' + minute
      },
      success: (res) => {
        wx.showToast({
          title: res.data.msg,
          icon: 'success',
          duration: 1500
        })
        let pages = getCurrentPages();   //获取小程序页面栈
        let beforePage = pages[pages.length - 2];  //获取上个页面的实例对象
        // beforePage.setData({      //直接修改上个页面的数据（可通过这种方式直接传递参数）
        //   txt: '修改数据了'
        // })
        beforePage.getList();   //触发上个页面自定义的go_update方法
        wx.navigateBack({
          delta: 1
        })
      }
    })  
  }
})