Page({
  data: {
    historyList: [] // 历史搜索列表
  },
  // 监听搜索框输入事件
  getInputVal(e) {
    this.setData({
      inputValue: e.detail.value
    });
  },
  // 点击搜索按钮，跳转到searchresult页面
  navigateToSearchResult() {
    const keyword = this.data.inputValue;
    // 存入历史搜索
    if (keyword && !this.data.historyList.includes(keyword)) {
      this.data.historyList.push(keyword);
      this.setData({
        historyList: this.data.historyList

      });

    }
    // 跳转到searchresult页面，将关键词作为参数传递 
    wx.navigateTo({
      url: '/pages/searchresult/searchresult?keyword=' + keyword
    });
  },


  // 点击清空历史搜索

  clearHistory() {

    this.setData({

      historyList: []

    });

  },


  // 点击历史搜索关键词，跳转到searchresult页面

  navigateToSearchResultByKeyword(e) {

    const keyword = e.currentTarget.dataset.keyword;

    wx.navigateTo({
      url: '../result/result?keyword=' + keyword
    });

  }

});