Page({
  data: {
    title: '',
    content: '',
    categories: ['生活服务', '出行帮助', '健康服务'],
    selectedCategoryIndex: 0,
    urgencyLevels: ['预约', '紧急'],
    selectedUrgencyIndex: 0,
    volunteerLimits: ['无限制', '其他限制'],
    selectedVolunteerLimitIndex: 0
  },
  onTitleInput(e) {
    this.setData({
      title: e.detail.value
    });
  },
  onContentInput(e) {
    this.setData({
      content: e.detail.value
    });
  },
  onCategoryChange(e) {
    this.setData({
      selectedCategoryIndex: e.detail.value
    });
  },
  onUrgencyChange(e) {
    this.setData({
      selectedUrgencyIndex: e.detail.value
    });
  },
  onVolunteerLimitChange(e) {
    this.setData({
      selectedVolunteerLimitIndex: e.detail.value
    });
  },
  onPublish() {
    const { title, content, categories, selectedCategoryIndex, urgencyLevels, selectedUrgencyIndex, volunteerLimits, selectedVolunteerLimitIndex } = this.data;
    if (!title || !content) {
      wx.showToast({
        title: '标题和内容不能为空',
        icon: 'none'
      });
      return;
    }
    // 发布需求的逻辑处理
    console.log('发布需求:', title, content, categories[selectedCategoryIndex], urgencyLevels[selectedUrgencyIndex], volunteerLimits[selectedVolunteerLimitIndex]);
    // 后端接口
  }
});
