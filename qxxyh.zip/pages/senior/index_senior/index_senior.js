Page({
  data: {

  },
  onLoad() {

  },
  goToEventsIndex(){
    wx:wx.navigateTo({
      url: '../events_index/events_index',
    })
    console.log("yes")
  },
  goToRequestPost(){
    wx:wx.navigateTo({
      url: '../request_post/request_post',
    })
  },
  goToMyEvents(){

  },
  goToMyRequests(){

  },
  smartService(){
    wx:wx.navigateTo({
      url: '../smart_service/smart_service',
    })
  },
  goToSettings(){

  },
  goToCallForHelp(){

  },
})