var app = getApp();

Page({
  data: {
    role:0,
    userInfo:''
  },

  onLoad(){
    let user=wx.getStorageSync('user')
    this.setData({
      userInfo:user
    })
  },

  // 用户选择角色
  setRole(e) {
    const selectedRole = e.currentTarget.dataset.role;
    this.setData({
      role: selectedRole,
    });
    app.globalData.role = selectedRole;
    console.log('选择的角色是：', this.data.role);
  },

  // 用户点击进入
  goIn() {
    if (this.data.role == 0) {
      console.log('跳转到志愿者登录页面');
      this.login('/pages/login/login');
    } else if (this.data.role == 1) {
      console.log('跳转到教职工首页');
      this.login('/pages/senior/index_senior/index_senior');
      //url: '/pages/senior/login_senior/login_senior',
    } else {
      // 如果没有选择角色或角色数据有误
      console.log('请选择一个角色');
      wx.showToast({
        title: '请选择一个角色',
        icon: 'none',
        duration: 2000
      });
    }
  },
  //授权登录
  login(redirectUrl){
    wx.getUserProfile({
      desc:'必须授权才能使用',
      success:res=>{
        let user=res.userInfo
        console.log("用户信息",user);
        
        // 获取用户的code
        wx.login({
          success: res => {
            if (res.code) {
              let code = res.code;
              console.log("openid:",code);
              // 将用户信息和code上传到服务器
              wx.request({
                url: '', //服务器接口地址
                method: 'POST',
                header: { "Content-Type": "application/x-www-form-urlencoded" },
                data: {
                  nickName: user.nickName,
                  avatarUrl: user.avatarUrl,
                  code: code
                },
                
                success: res => {
                  let info = res.data;
                  console.log(info);
                  
                  if(info.errCode == 0){
                    wx.showToast({
                      title: info.errMsg,
                      icon: 'success'
                    });
                    
                    // 把openid、nickName、avatarUrl缓存在本地
                    wx.setStorageSync('openid', info.data.openid)
                    let nickName=user.nickName
                    let avatarUrl=user.avatarUrl
                    wx.setStorageSync('nickName', nickName)
                    wx.setStorageSync('avatarUrl', avatarUrl)
                    // 把code缓存在本地
                    wx.setStorageSync('code', res.code);
                    console.log('nickName:',nickName);
                    console.log('avatarUrl:',avatarUrl);
                    console.log(code);
                    // 把用户信息缓存在本地
                    wx.setStorageSync('user', user)
                    this.setData({
                      userInfo:user
                    })
                  }
                },
                fail: res => {
                  console.log("请求失败", res)
                }
              })
            } else {
              console.log('登录失败！' + res.errMsg)
            }
          }
        })
        
      },
      
      fail:res=>{
        console.log("失败",res)
      }
    })
    
  },
})